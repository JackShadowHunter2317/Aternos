const Discord = require('discord.js');
const puppeteer = require('puppeteer');
const express = require('express');

// Create Express server to keep Replit alive
const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
    res.send('Aternos Bot is running!');
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// Discord client setup
const client = new Discord.Client({
    intents: [
        Discord.GatewayIntentBits.Guilds,
        Discord.GatewayIntentBits.GuildMessages,
        Discord.GatewayIntentBits.MessageContent
    ]
});

// Configuration from Replit Secrets
const CONFIG = {
    DISCORD_TOKEN: process.env.DISCORD_TOKEN,
    ATERNOS_USERNAME: process.env.ATERNOS_USERNAME,
    ATERNOS_PASSWORD: process.env.ATERNOS_PASSWORD,
    SERVER_NAME: process.env.SERVER_NAME,
    ALLOWED_ROLE: process.env.ALLOWED_ROLE || 'Admin',
    COMMAND_PREFIX: process.env.COMMAND_PREFIX || '!'
};

/**
 * Starts the Aternos server
 */
async function startAternosServer(username, password, serverName) {
    let browser;
    
    try {
        console.log('Launching browser...');
        browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ],
            executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/nix/store/4zih9w0nhx8ByteNWb9MlM6xsj6QkpZ-chromium-130.0.6723.116/bin/chromium'
        });
        
        const page = await browser.newPage();
        
        await page.setViewport({ width: 1280, height: 720 });
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        
        console.log('Navigating to Aternos...');
        await page.goto('https://aternos.org/:it/', { 
            waitUntil: 'networkidle2',
            timeout: 30000 
        });
        
        await page.waitForTimeout(2000);
        
        // Click login button
        console.log('Clicking login...');
        await page.waitForSelector('a[href*="go/login"], .login-button, #login', { timeout: 10000 });
        const loginButton = await page.$('a[href*="go/login"]') || await page.$('.login-button') || await page.$('#login');
        await loginButton.click();
        
        await page.waitForTimeout(2000);
        
        // Fill credentials
        console.log('Entering credentials...');
        await page.waitForSelector('input[name="user"], #user', { timeout: 10000 });
        
        const userInput = await page.$('input[name="user"]') || await page.$('#user');
        const passInput = await page.$('input[name="password"]') || await page.$('#password');
        
        await userInput.type(username, { delay: 100 });
        await passInput.type(password, { delay: 100 });
        
        // Submit
        console.log('Logging in...');
        const submitButton = await page.$('button[type="submit"]') || await page.$('.login-submit');
        await submitButton.click();
        
        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 20000 });
        
        console.log('Login successful!');
        await page.waitForTimeout(3000);
        
        // Find server
        console.log(`Looking for server: ${serverName}...`);
        await page.waitForSelector('.server-body, .server-card', { timeout: 15000 });
        
        const servers = await page.$$('.server-body, .server-card');
        let serverFound = false;
        
        for (const server of servers) {
            const nameElement = await server.$('.server-name, .servername');
            if (nameElement) {
                const name = await page.evaluate(el => el.textContent.trim(), nameElement);
                if (name === serverName || name.includes(serverName)) {
                    console.log(`Found server: ${name}`);
                    await server.click();
                    serverFound = true;
                    break;
                }
            }
        }
        
        if (!serverFound) {
            console.log('Trying alternative method to find server...');
            const allText = await page.evaluate(() => document.body.innerText);
            if (!allText.includes(serverName)) {
                throw new Error('Server not found in your Aternos account!');
            }
        }
        
        await page.waitForTimeout(3000);
        
        // Click start button
        console.log('Looking for start button...');
        await page.waitForSelector('#start, .start-button, button[data-action="start"]', { timeout: 10000 });
        
        const startButton = await page.$('#start') || await page.$('.start-button') || await page.$('button[data-action="start"]');
        
        if (!startButton) {
            throw new Error('Start button not found!');
        }
        
        await startButton.click();
        console.log('Server start command sent!');
        await page.waitForTimeout(3000);
        
        // Logout
        console.log('Logging out...');
        await page.goto('https://aternos.org/go/logout/', { waitUntil: 'networkidle2' });
        
        console.log('Process completed successfully!');
        return { success: true, message: 'Server started successfully!' };
        
    } catch (error) {
        console.error('Error:', error.message);
        return { success: false, message: error.message };
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

// Discord bot events
client.on('ready', () => {
    console.log(`✅ Bot logged in as ${client.user.tag}!`);
    client.user.setActivity('!startserver', { type: Discord.ActivityType.Listening });
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    const prefix = CONFIG.COMMAND_PREFIX;
    
    // Start server command
    if (message.content.toLowerCase() === `${prefix}startserver`) {
        
        // Check permissions
        if (!message.member.roles.cache.some(role => role.name === CONFIG.ALLOWED_ROLE)) {
            return message.reply('❌ You need the `' + CONFIG.ALLOWED_ROLE + '` role to use this command!');
        }
        
        const statusMessage = await message.reply('🔄 Starting Aternos server... This may take up to 1 minute...');
        
        try {
            const result = await startAternosServer(
                CONFIG.ATERNOS_USERNAME,
                CONFIG.ATERNOS_PASSWORD,
                CONFIG.SERVER_NAME
            );
            
            if (result.success) {
                await statusMessage.edit('✅ ' + result.message + '\n⏳ The server should be online in 2-3 minutes.');
            } else {
                await statusMessage.edit('❌ Failed: ' + result.message);
            }
            
        } catch (error) {
            console.error('Command error:', error);
            await statusMessage.edit('❌ An unexpected error occurred. Check console logs.');
        }
    }
    
    // Help command
    if (message.content.toLowerCase() === `${prefix}help`) {
        const helpEmbed = new Discord.EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎮 Aternos Server Bot')
            .setDescription('Automatically start your Aternos Minecraft server!')
            .addFields(
                { name: `${prefix}startserver`, value: '▶️ Starts the Aternos server', inline: true },
                { name: `${prefix}help`, value: '❓ Shows this help message', inline: true }
            )
            .setFooter({ text: 'Only users with the ' + CONFIG.ALLOWED_ROLE + ' role can start the server' })
            .setTimestamp();
        
        message.reply({ embeds: [helpEmbed] });
    }
    
    // Status command
    if (message.content.toLowerCase() === `${prefix}status`) {
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        
        const statusEmbed = new Discord.EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🤖 Bot Status')
            .addFields(
                { name: '🟢 Status', value: 'Online', inline: true },
                { name: '⏱️ Uptime', value: `${hours}h ${minutes}m`, inline: true },
                { name: '🎯 Server', value: CONFIG.SERVER_NAME, inline: true }
            )
            .setTimestamp();
        
        message.reply({ embeds: [statusEmbed] });
    }
});

// Error handling
client.on('error', error => {
    console.error('Discord client error:', error);
});

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

// Login
console.log('Starting bot...');
client.login(CONFIG.DISCORD_TOKEN).catch(error => {
    console.error('Failed to login:', error);
});
