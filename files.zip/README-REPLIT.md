# 🤖 Aternos Discord Bot for Replit

A Discord bot that automatically starts your Aternos Minecraft server with a simple command!

## ⚠️ Important: This is NOT for the Dyno Bot

**Dyno is a pre-made bot service** - you cannot add custom scripts to it. This creates your **OWN custom bot** that will run alongside Dyno (or any other bots) in your Discord server.

---

## 📋 Quick Setup Guide for Replit

### Step 1: Create a New Repl

1. Go to [Replit](https://replit.com)
2. Click **"+ Create Repl"**
3. Choose **"Node.js"** as the template
4. Name it something like "Aternos-Bot"
5. Click **"Create Repl"**

### Step 2: Upload Files

Upload these files to your Repl:
- `index.js`
- `package.json`
- `.replit`
- `replit.nix`

### Step 3: Create a Discord Bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **"New Application"**
3. Give it a name (e.g., "Aternos Server Manager")
4. Go to **"Bot"** section on the left
5. Click **"Add Bot"** → **"Yes, do it!"**
6. **Important:** Under "Privileged Gateway Intents", enable:
   - ✅ **MESSAGE CONTENT INTENT**
   - ✅ Server Members Intent (optional)
7. Click **"Reset Token"** → **"Copy"** (save this token!)

### Step 4: Invite Bot to Your Server

1. Go to **"OAuth2"** → **"URL Generator"**
2. Select scopes:
   - ✅ `bot`
3. Select bot permissions:
   - ✅ Send Messages
   - ✅ Read Messages/View Channels
   - ✅ Embed Links
   - ✅ Read Message History
4. Copy the generated URL at the bottom
5. Open the URL in your browser and add the bot to your server

### Step 5: Configure Replit Secrets

In Replit, click on **"Secrets"** (🔒 lock icon) on the left sidebar, then add these secrets:

| Key | Value | Example |
|-----|-------|---------|
| `DISCORD_TOKEN` | Your Discord bot token | `MTIzNDU2Nzg5MDEyMzQ1Njc4OQ.GhIJkL.MnOpQrStUvWxYz...` |
| `ATERNOS_USERNAME` | Your Aternos email/username | `yourname@example.com` |
| `ATERNOS_PASSWORD` | Your Aternos password | `your_password_here` |
| `SERVER_NAME` | Your server's exact name on Aternos | `MyMinecraftServer` |
| `ALLOWED_ROLE` | Discord role that can use bot | `Admin` |
| `COMMAND_PREFIX` | Command prefix | `!` |

**⚠️ IMPORTANT:** 
- The `SERVER_NAME` must match **exactly** as it appears on Aternos (case-sensitive!)
- Keep your secrets private - never share them!

### Step 6: Run the Bot

1. Click the **"Run"** button at the top
2. Wait for installation to complete
3. You should see: `✅ Bot logged in as YourBot#1234!`

### Step 7: Test in Discord

In your Discord server, type:
```
!help
```

You should see a help menu. Then try:
```
!startserver
```

The bot will:
1. Log into Aternos
2. Find your server
3. Click the start button
4. Log out
5. Notify you when done!

---

## 🎮 Available Commands

| Command | Description | Who Can Use |
|---------|-------------|-------------|
| `!startserver` | Starts your Aternos Minecraft server | Users with the allowed role |
| `!help` | Shows available commands | Everyone |
| `!status` | Shows bot status and uptime | Everyone |

---

## 🔧 Troubleshooting

### Bot is offline in Discord
- Check if your Repl is running
- Verify the `DISCORD_TOKEN` is correct
- Make sure "MESSAGE CONTENT INTENT" is enabled

### "You need the Admin role" error
- Create a Discord role with the exact name you put in `ALLOWED_ROLE`
- Assign this role to users who should be able to start the server

### "Server not found" error
- Double-check `SERVER_NAME` matches exactly (case-sensitive!)
- Make sure you can see the server when logged into Aternos
- Try logging into Aternos manually to verify your credentials

### Puppeteer/Chromium errors
- Make sure `replit.nix` file is present
- Try restarting the Repl
- Check if Chromium is installed by running: `which chromium`

### Bot keeps going offline
- Replit free tier puts inactive Repls to sleep
- **Solution 1:** Use UptimeRobot to ping your bot every 5 minutes
  - Go to [uptimerobot.com](https://uptimerobot.com)
  - Create a monitor for `https://your-repl-name.your-username.repl.co`
- **Solution 2:** Upgrade to Replit Hacker plan

---

## 🔄 Keeping Your Bot Online 24/7 (Free Method)

1. **UptimeRobot Setup:**
   - Sign up at [uptimerobot.com](https://uptimerobot.com) (free)
   - Click **"Add New Monitor"**
   - Monitor Type: **HTTP(s)**
   - Friendly Name: `Aternos Bot`
   - URL: Your Repl's URL (found in the webview panel)
   - Monitoring Interval: **5 minutes**
   - Click **"Create Monitor"**

2. This will ping your bot every 5 minutes, keeping it awake!

---

## ⚙️ Customization

### Change Command Prefix

In Replit Secrets, change `COMMAND_PREFIX` to whatever you want:
- `!` → `!startserver`
- `/` → `/startserver`
- `$` → `$startserver`

### Change Required Role

Update `ALLOWED_ROLE` in Secrets to the role name that should be able to use the bot.

### Multiple Servers

Currently, the bot starts one specific server. To support multiple servers, you would need to:
1. Add a parameter to the command (e.g., `!startserver MyServer1`)
2. Modify the code to accept the server name as an argument

---

## 🆚 This Bot vs Dyno

| Feature | Your Custom Bot | Dyno |
|---------|----------------|------|
| Start Aternos Server | ✅ Yes | ❌ No |
| Custom Commands | ✅ Unlimited | ⚠️ Limited |
| Moderation Tools | ❌ No | ✅ Yes |
| Music Bot | ❌ No | ✅ Yes |
| Free | ✅ Yes | ✅ Yes (with limits) |

**You can use BOTH bots together!** They don't conflict with each other.

---

## 📝 Notes

- **Aternos has rate limits** - don't spam the command or you might get blocked
- The server takes **2-3 minutes** to fully start after the command
- This is for **personal/educational use** - respect Aternos's Terms of Service
- Automated access may be against Aternos policies - use at your own risk

---

## 🐛 Still Having Issues?

Common fixes:
1. **Restart the Repl** - Click Stop, then Run again
2. **Check all Secrets are set** - Go through each one carefully
3. **Verify Discord permissions** - Bot needs "Send Messages" permission
4. **Check Aternos website** - Make sure it's not down
5. **View Console logs** - Look for error messages in the Repl console

---

## 🔐 Security Best Practices

- ✅ Never share your Secrets
- ✅ Never commit Secrets to GitHub
- ✅ Use strong passwords
- ✅ Limit who has the required role in Discord
- ✅ Monitor bot usage regularly

---

## 📜 License

MIT License - Use freely but at your own risk!

---

## 🎉 Success!

Once everything is working, you can start your Minecraft server from Discord with a single command! Enjoy gaming! 🎮
